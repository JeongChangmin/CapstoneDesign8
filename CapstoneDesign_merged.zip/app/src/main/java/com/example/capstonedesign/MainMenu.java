package com.example.capstonedesign;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.capstonedesign.ui.MapActivity;
import com.google.firebase.auth.FirebaseAuth;

public class MainMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        final Intent MapIntent = new Intent(this, MapActivity.class);

        Button CreateCourse = (Button) findViewById(R.id.wrtitebutton);
        CreateCourse.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View view){
                startActivity(MapIntent);
            }
        });

        findViewById(R.id.logout).setOnClickListener(onClickListener);

    }



    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch(v.getId()){
                case R.id.logout:
                    FirebaseAuth.getInstance().signOut();  //서버로부터 로그아웃
                    startloginactivity();   // 메인로그인화면으로 이동

                break;
            }
        }
    };

    //함수 로그인
    private void  startloginactivity(){
        Intent intent = new Intent(this, Login.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); //스택초기화
        startActivity(intent);
    }
}
