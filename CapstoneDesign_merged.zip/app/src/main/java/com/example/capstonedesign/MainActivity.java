package com.example.capstonedesign;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



     if(FirebaseAuth.getInstance().getCurrentUser() == null){  // 현재 서버에 계정이 로그인이 되어 있는지 판단
         Handler handler = new Handler(){
             public void handleMessage (Message msg){  //로그인 안되어 있을시 로그인창으로 이동
                 super .handleMessage(msg);
                 startActivity(new Intent(MainActivity.this, Login.class));
                 finish();
             }
         };

         handler.sendEmptyMessageDelayed(0,3000);
     }else{
         Handler handler = new Handler(){
             public void handleMessage (Message msg){  // 로그인이 되어 있을시 메인메뉴로 이동
                 super .handleMessage(msg);
                 startActivity(new Intent(MainActivity.this, MainMenu.class));
                 finish();
             }
         };

         handler.sendEmptyMessageDelayed(0,3000);

     }

    }
}
